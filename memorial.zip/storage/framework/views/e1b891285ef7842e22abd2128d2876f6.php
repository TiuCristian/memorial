

<div class="memorial-bg"></div>

<div class="container d-flex align-items-center justify-content-center min-vh-100 py-5">
  <div class="memorial-card shadow-lg">
    <div class="p-4 p-md-5">
      <h2 class="fw-bold text-center mb-2">Adaugă o amintire</h2>
      <p class="text-center text-muted mb-4">Împărtășește un gând, o poveste sau o fotografie video despre Dana.</p>

      <?php if(session('status')): ?>
        <div class="alert alert-success text-center rounded-pill shadow-sm mb-4"><?php echo e(session('status')); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('memories.store')); ?>" enctype="multipart/form-data" class="form-modern" novalidate>
        <?php echo csrf_field(); ?>

        
        <div class="form-floating mb-3">
          <input type="text" class="form-control form-control-lg glass-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 id="name" name="name" placeholder="Ex: Maria Popescu" value="<?php echo e(old('name')); ?>">
          <label for="name">Nume și prenume</label>
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php else: ?>
          <div class="form-text">Poți folosi și doar prenumele, dacă preferi.</div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="form-floating mb-3">
          <input type="text" class="form-control form-control-lg glass-input <?php $__errorArgs = ['relation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 id="relation" name="relation" placeholder="Ex: prietenă, colegă, verișoară" value="<?php echo e(old('relation')); ?>">
          <label for="relation">Relația ta cu Dana</label>
          <?php $__errorArgs = ['relation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php else: ?>
          <div class="form-text">Ex: prieten(ă), coleg(ă) de serviciu, verișoară, vecin(ă)</div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="form-floating mb-3">
          <textarea class="form-control glass-input <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Scrie aici…"
                    id="message" name="message" style="height: 150px"><?php echo e(old('message')); ?></textarea>
          <label for="message">Gândurile sau amintirea ta</label>
          <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php else: ?>
          <div class="form-text">Ce îți amintești cu drag despre Dana?</div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
          <label for="media" class="form-label fw-semibold">Fotografie sau video (opțional)</label>
          <input class="form-control glass-input <?php $__errorArgs = ['media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="media" name="media"
                 accept=".jpg,.jpeg,.png,.webp,.mp4,.mov,.avi">
          <div class="form-text">Acceptăm .jpg, .png, .webp, .mp4 (max 10MB).</div>
          <?php $__errorArgs = ['media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="form-check mb-4">
          <input class="form-check-input" type="checkbox" value="1" id="consent" name="consent" <?php echo e(old('consent') ? 'checked' : ''); ?>>
          <label class="form-check-label" for="consent">
            Sunt de acord ca mesajul și fișierul atașat să fie publicate pe pagina memorială.
          </label>
          <?php $__errorArgs = ['consent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <button type="submit" class="btn btn-memorial w-100">
          Trimite amintirea <span class="btn-icon">→</span>
        </button>

        <p class="text-muted small text-center mt-3 mb-0">Amintirile apar după aprobare.</p>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\memorial\resources\views/home.blade.php ENDPATH**/ ?>